#-------------------------------------------------------------------------------
# Copyright (C) 2017 Carlos Guzman (cguZZman) carlosguzmang@protonmail.com
# 
# This file is part of Google Drive for Kodi
# 
# Google Drive for Kodi is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# Cloud Drive Common Module for Kodi is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#-------------------------------------------------------------------------------

import urllib
import datetime
import copy

from clouddrive.common.remote.provider import Provider
from clouddrive.common.remote.request import Request
from clouddrive.common.utils import Utils
from clouddrive.common.ui.logger import Logger
from clouddrive.common.ui.utils import KodiUtils
from clouddrive.common.exception import RequestException, ExceptionUtils
from clouddrive.common.cache.cache import Cache
try:
    from urllib.error import HTTPError
except ImportError:
    from urllib2 import HTTPError

class GoogleDrive(Provider):
    folder_paging_supported = True
    revoke_supported = True
    signin_company = 'Google'
    _REVOKE_URL = 'https://oauth2.googleapis.com/revoke'
    _default_parameters = {'spaces': 'drive', 'supportsAllDrives': 'true', 'prettyPrint': 'false'}
    _is_shared_drive = False
    _shared_drive_parameters = {'includeItemsFromAllDrives': 'true', 'corpora': 'drive', 'driveId': ''}
    _user = None

    def __init__(self, source_mode = False):
        super(GoogleDrive, self).__init__('googledrive', source_mode)
        self.download_requires_auth = True
        self._items_cache = Cache(KodiUtils.get_addon_info('id'), 'items', datetime.timedelta(minutes=KodiUtils.get_cache_expiration_time()))
            

    def revoke_access(self):
        # Revoking the refresh token ends the app's access to the Google account, on every device signed in with it.
        # Google answers 400 when the token is already invalid (revoked or expired): nothing left to revoke.
        tokens = self.get_access_tokens()
        try:
            Request(self._REVOKE_URL, urllib.parse.urlencode({'token': tokens['refresh_token']}), {'content-type': 'application/x-www-form-urlencoded'}, tries=2).request()
        except Exception as e:
            httpex = ExceptionUtils.extract_exception(e, HTTPError)
            if not httpex or httpex.code != 400:
                raise
    def configure(self, account_manager, driveid):
        super(GoogleDrive, self).configure(account_manager, driveid)
        drive = account_manager.get_by_driveid('drive', driveid)
        self._is_shared_drive = drive and 'type' in drive and (drive['type'] == 'drive#drive' or drive['type'] == 'drive#teamDrive')
        
    def _get_api_url(self):
        return 'https://www.googleapis.com/drive/v3'

    def _get_request_headers(self):
        return None
    
    def get_account(self, request_params=None, access_tokens=None):
        me = self.get('/about', parameters={'fields':'user'}, request_params=request_params, access_tokens=access_tokens)
        if not me or not 'user' in me:
            raise Exception('NoAccountInfo')
        self._user = me['user'] 
        # Only drive.readonly is requested (no 'profile'); the Drive user still has displayName, with fallbacks just in case.
        name = Utils.get_safe_value(self._user, 'displayName') or Utils.get_safe_value(self._user, 'emailAddress') or self._user['permissionId']
        return { 'id' : self._user['permissionId'], 'name' : name}
    
    def get_drives(self, request_params=None, access_tokens=None):
        drives = [{
            'id' : self._user['permissionId'],
            'name' : '',
            'type' : ''
        }]
        try:
            all_shareddrives_fetch = False
            page_token = None
            parameters = {'pageSize': 100}
            while not all_shareddrives_fetch:
                if page_token:
                    parameters['pageToken'] = page_token
                response = self.get('/drives', parameters=parameters, request_params=request_params, access_tokens=access_tokens)
                if response and 'drives' in response:
                    for drive in response['drives']:
                        drives.append({
                            'id' : drive['id'],
                            'name' : Utils.get_safe_value(drive, 'name', drive['id']),
                            'type' : drive['kind']
                        })
                if response and 'nextPageToken' in response:
                    page_token = response['nextPageToken']
                else:
                    all_shareddrives_fetch = True
        except RequestException as ex:
            httpex = ExceptionUtils.extract_exception(ex, HTTPError)
            if not httpex or httpex.code != 403:
                raise ex
        return drives
    
    def get_drive_type_name(self, drive_type):
        if drive_type == 'drive#drive' or drive_type == 'drive#teamDrive':
            return 'Shared Drive'
        return drive_type
    
    def prepare_parameters(self):
        parameters = copy.deepcopy(self._default_parameters)
        if self._is_shared_drive:
            parameters.update(self._shared_drive_parameters)
            parameters['driveId'] = self._driveid
        return parameters
    
    @staticmethod
    def _quote(value):
        # A value inside single quotes in a Drive query: backslashes and quotes are escaped.
        return Utils.str(value).replace('\\', '\\\\').replace("'", "\\'")

    def _use_folder_drive(self, folder_id, parameters):
        # A shared drive's folder reached from My Drive through a shortcut lists nothing with My Drive's parameters.
        # Called when a listing came back empty: if the folder is in a shared drive, its drive's parameters are set.
        if self._is_shared_drive or folder_id == 'root':
            return False
        f = self.get('/files/%s' % folder_id, parameters = {'fields': 'driveId', 'supportsAllDrives': 'true'})
        drive_id = Utils.get_safe_value(f, 'driveId')
        if not drive_id:
            return False
        parameters.update(self._shared_drive_parameters)
        parameters['driveId'] = drive_id
        return True

    def _get_field_parameters(self):
        file_fileds = 'id,name,modifiedTime,size,mimeType'
        if not self.source_mode:
            file_fileds = file_fileds + ',description,hasThumbnail,thumbnailLink,owners(permissionId),parents,trashed,imageMediaMetadata(width),videoMediaMetadata,shortcutDetails'
        return file_fileds
        
    # Parent folders per query when listing a tree for library exports (list_subtree).
    _SUBTREE_BATCH = 100

    def _folder_query(self, item_id, path, include_download_info=False):
        # The parameters that list a folder, and the folder's id (None for the root and the special views).
        parameters = self.prepare_parameters()
        folder_id = None
        if item_id:
            folder_id = item_id
        elif path == 'sharedWithMe' or path == 'starred':
            parameters['q'] = path
        elif path == '/':
            parent = self._driveid if self._is_shared_drive else 'root'
            parameters['q'] = '\'%s\' in parents' % parent
        else:
            folder_id = self.get_item_by_path(path, include_download_info)['id']
        if folder_id:
            parameters['q'] = '\'%s\' in parents' % folder_id
                
        parameters['fields'] = 'files(%s),kind,nextPageToken' % self._get_field_parameters()
        if 'q' in parameters:
            parameters['q'] += ' and not trashed'
        
        self.configure(self._account_manager, self._driveid)
        return parameters, folder_id

    def get_folder_items(self, item_driveid=None, item_id=None, path=None, on_items_page_completed=None, include_download_info=False, on_before_add_item=None):
        parameters, folder_id = self._folder_query(item_id, path, include_download_info)
        parameters['pageSize'] = 1000
        files = self.get('/files', parameters = parameters)
        if folder_id and not Utils.get_safe_value(files, 'files') and self._use_folder_drive(folder_id, parameters):
            files = self.get('/files', parameters = parameters)
        if self.cancel_operation():
            return
        items = []
        items.extend(self.process_files(files, parameters, on_items_page_completed, include_download_info, on_before_add_item=on_before_add_item))
        return items
    
    # Next page tokens of a shared drive's folder reached through a shortcut carry the drive: "drive:<id>:<token>".
    _DRIVE_PAGE_TOKEN = 'drive:'

    def get_folder_page(self, item_driveid=None, item_id=None, path=None, page_size=500, page_token=None, on_items_page_completed=None):
        if path == 'sharedWithMe' or path == 'starred':
            # Not paged: listed whole, as before.
            items = self.get_folder_items(item_driveid, item_id, path, on_items_page_completed)
            return None if items is None else (items, None)
        parameters, folder_id = self._folder_query(item_id, path)
        parameters['pageSize'] = page_size
        # Folders first, then by name: each page follows the one before.
        parameters['orderBy'] = 'folder,name'
        folder_drive = None
        if page_token and page_token.startswith(self._DRIVE_PAGE_TOKEN):
            folder_drive, page_token = page_token[len(self._DRIVE_PAGE_TOKEN):].split(':', 1)
            parameters.update(self._shared_drive_parameters)
            parameters['driveId'] = folder_drive
        if page_token:
            parameters['pageToken'] = page_token
        files = self.get('/files', parameters = parameters)
        if not page_token and folder_id and not Utils.get_safe_value(files, 'files') and self._use_folder_drive(folder_id, parameters):
            folder_drive = parameters['driveId']
            files = self.get('/files', parameters = parameters)
        if self.cancel_operation():
            return
        next_page_token = files.pop('nextPageToken', None)
        if next_page_token and folder_drive:
            next_page_token = '%s%s:%s' % (self._DRIVE_PAGE_TOKEN, folder_drive, next_page_token)
        return self.process_files(files, parameters, on_items_page_completed), next_page_token

    def list_subtree(self, item_driveid, item_id):
        # The tree breadth-first, with many parent folders per query: about one request per level instead of one per
        # folder. Based on plugin.googledrive#320 by 0o120 (28 requests instead of 2,317 for 2,292 movies).
        base_parameters = self.prepare_parameters()
        base_parameters['fields'] = 'files(%s),kind,nextPageToken' % self._get_field_parameters()
        base_parameters['pageSize'] = 1000
        self.configure(self._account_manager, self._driveid)
        tree = {item_id: []}
        pending = [item_id]
        checked_drive = False
        while pending:
            batch, pending = pending[:self._SUBTREE_BATCH], pending[self._SUBTREE_BATCH:]
            parameters = copy.deepcopy(base_parameters)
            parameters['q'] = '(%s) and not trashed' % ' or '.join('\'%s\' in parents' % self._quote(folder_id) for folder_id in batch)
            files = self.get('/files', parameters = parameters)
            if self.cancel_operation():
                return None
            items = self.process_files(files, parameters, include_download_info=True)
            if items is None:
                return None
            if not items and batch == [item_id] and not checked_drive:
                # The tree may be in a shared drive (exported through a shortcut): listed again with its drive's parameters.
                checked_drive = True
                if self._use_folder_drive(item_id, base_parameters):
                    pending = [item_id]
                    continue
            for item in items:
                if item['parent'] in tree:
                    tree[item['parent']].append(item)
                # A folder seen before (a shortcut back to an ancestor) is not listed again.
                if 'folder' in item and item['id'] not in tree:
                    tree[item['id']] = []
                    pending.append(item['id'])
        return tree

    def search(self, query, item_driveid=None, item_id=None, on_items_page_completed=None):
        item_driveid = Utils.default(item_driveid, self._driveid)
        parameters = self.prepare_parameters()
        parameters['fields'] = 'files(%s),kind,nextPageToken' % self._get_field_parameters()
        query = 'fullText contains \'%s\'' % self._quote(query)
        if item_id:
            query += ' and \'%s\' in parents' % item_id
        parameters['q'] = query + ' and not trashed'
        parameters['pageSize'] = 1000
        files = self.get('/files', parameters = parameters)
        if self.cancel_operation():
            return
        return self.process_files(files, parameters, on_items_page_completed)
    
    def process_files(self, files, parameters, on_items_page_completed=None, include_download_info=False, extra_info=None, on_before_add_item=None):
        items = []
        if files:
            kind = Utils.get_safe_value(files, 'kind', '')
            collection = []
            if kind == 'drive#fileList':
                collection = files['files']
            elif kind == 'drive#changeList':
                collection = files['changes']
            if collection:
                for f in collection:
                    f['kind'] = Utils.get_safe_value(f, 'kind', kind)
                    item = self._extract_item(f, include_download_info)
                    if item:
                        if on_before_add_item:
                            on_before_add_item(item)
                        items.append(item)
                if on_items_page_completed:
                    on_items_page_completed(items)
            if type(extra_info) is dict:
                if 'newStartPageToken' in files:
                    extra_info['change_token'] = files['newStartPageToken']
            if 'nextPageToken' in files:
                parameters['pageToken'] = files['nextPageToken']
                url = '/files'
                if kind == 'drive#changeList':
                    url = '/changes'
                next_files = self.get(url, parameters = parameters)
                if self.cancel_operation():
                    return
                items.extend(self.process_files(next_files, parameters, on_items_page_completed, include_download_info, extra_info, on_before_add_item))
        return items
    
    def _extract_item(self, f, include_download_info=False):
        kind = Utils.get_safe_value(f, 'kind', '')
        if kind == 'drive#change':
            change_type = Utils.get_safe_value(f, 'changeType', '')
            if change_type == 'file':
                if 'file' in f:
                    f = f['file']
                else:
                    f['id'] = Utils.get_safe_value(f, 'fileId')
                    f['trashed'] = Utils.get_safe_value(f, 'removed')
                    f['modifiedTime'] = Utils.get_safe_value(f, 'time')
            else:
                return {}
        size = int('%s' % Utils.get_safe_value(f, 'size', 0))
        item_id = f['id']
        mimetype = Utils.get_safe_value(f, 'mimeType', '')
        name = Utils.get_safe_value(f, 'name', '')
        if mimetype == 'application/vnd.google-apps.shortcut':
            shortcut = Utils.get_safe_value(f, 'shortcutDetails') 
            item_id = Utils.get_safe_value(shortcut, 'targetId', item_id)
            mimetype = Utils.get_safe_value(shortcut, 'targetMimeType', mimetype)
        item = {
            'id': item_id,
            'name': name,
            'name_extension' : Utils.get_extension(name),
            'parent': Utils.get_safe_value(f, 'parents', ['root'])[0],
            'drive_id' : Utils.get_safe_value(Utils.get_safe_value(f, 'owners', [{}])[0], 'permissionId'),
            'mimetype' : mimetype,
            'last_modified_date' : Utils.get_safe_value(f,'modifiedTime'),
            'size': size,
            'description': Utils.get_safe_value(f, 'description', ''),
            'deleted' : Utils.get_safe_value(f, 'trashed', False)
        }
        if item['mimetype'] == 'application/vnd.google-apps.folder':
            item['folder'] = {
                'child_count' : 0
            }
        if 'videoMediaMetadata' in f:
            video = f['videoMediaMetadata']
            item['video'] = {
                'width' : Utils.get_safe_value(video, 'width'),
                'height' : Utils.get_safe_value(video, 'height'),
                'duration' : int('%s' % Utils.get_safe_value(video, 'durationMillis', 0)) / 1000
            }
        if 'imageMediaMetadata' in f:
            item['image'] = {
                'size' : size
            }
        if 'hasThumbnail' in f and f['hasThumbnail']:
            item['thumbnail'] = Utils.get_safe_value(f, 'thumbnailLink')
        if include_download_info:
            parameters = {
                'alt': 'media',
            }
            url = self._get_api_url() + '/files/%s' % item['id']
            if 'size' not in f and item['mimetype'] == 'application/vnd.google-apps.document':
                url += '/export'
                parameters['mimeType'] = Utils.default(Utils.get_mimetype_by_extension(item['name_extension']), Utils.get_mimetype_by_extension('pdf'))
            url += '?%s' % urllib.parse.urlencode(parameters)
            item['download_info'] =  {
                'url' : url
            }
        return item
    
    def get_item_by_path(self, path, include_download_info=False):
        parameters = self.prepare_parameters()
        if path[-1:] == '/':
            path = path[:-1]
        Logger.debug(path + ' <- Target')
        key = '%s%s' % (self._driveid, path,)
        Logger.debug('Testing item from cache: %s' % key)
        item = self._items_cache.get(key)
        if not item:
            parameters['fields'] = 'files(%s)' % self._get_field_parameters()
            index = path.rfind('/')
            # Decoded paths come from clouddrive.common 1.5.7 on, encoded ones before: decoding again works for both.
            filename = urllib.parse.unquote(path[index+1:])
            parent = path[0:index]
            if not parent:
                parent = self._driveid if self._is_shared_drive else 'root'
            else:
                parent = self.get_item_by_path(parent, include_download_info)['id']
            item = None
            parameters['q'] = '\'%s\' in parents and name = \'%s\' and not trashed' % (self._quote(parent), self._quote(filename))
            parameters['pageSize'] = 1000
            files = self.get('/files', parameters = parameters)
            if not files['files'] and self._use_folder_drive(parent, parameters):
                files = self.get('/files', parameters = parameters)
            if (len(files['files']) > 0):
                for f in files['files']:
                    item = self._extract_item(f, include_download_info)
                    break
        else:
            Logger.debug('Found in cache.')
        if not item:
            raise RequestException('Not found by path', HTTPError(path, 404, 'Not found', None, None), 'Request URL: %s' % path, None)
        
        else:
            self._items_cache.set(key, item)
        return item
    
    def get_subtitles(self, parent, name, item_driveid=None, include_download_info=False):
        # Subtitles stored next to the video, named after it: Movie.srt, Movie.en.srt (not Movie 2.srt). From the
        # folder's listing: Drive's "name contains" found nothing for some names, like "a (1234) [h264 • DD 5.1]" (#251).
        stem = Utils.str(Utils.remove_extension(name))
        if parent:
            items = self.get_folder_items(item_driveid, parent, include_download_info=include_download_info) or []
        else:
            parameters = self.prepare_parameters()
            parameters['fields'] = 'files(' + self._get_field_parameters() + ')'
            parameters['q'] = 'name contains \'%s\' and not trashed' % self._quote(stem)
            parameters['pageSize'] = 1000
            files = self.get('/files', parameters = parameters)
            items = [self._extract_item(f, include_download_info) for f in files['files']]
        subtitles = []
        for subtitle in items:
            if 'folder' not in subtitle and Utils.default(subtitle['name_extension'], '').lower() in ('srt','idx','sub','sbv','ass','ssa','smi','vtt') and Utils.str(subtitle['name']).lower().startswith(stem.lower() + '.'):
                subtitles.append(subtitle)
        return subtitles
    
    def get_item(self, item_driveid=None, item_id=None, path=None, find_subtitles=False, include_download_info=False):
        parameters = self.prepare_parameters()
        item_driveid = Utils.default(item_driveid, self._driveid)
        parameters['fields'] = self._get_field_parameters()
        if not item_id and path == '/':
            item_id = 'root'
        if item_id:
            f = self.get('/files/%s' % item_id, parameters = parameters)
            item = self._extract_item(f, include_download_info)
        else:
            item = self.get_item_by_path(path, include_download_info)
        
        if find_subtitles:
            subtitles = self.get_subtitles(item['parent'], item['name'], item_driveid, include_download_info)
            if subtitles:
                item['subtitles'] = subtitles
        return item
    
    def changes(self):
        change_token = self.get_change_token()
        if not change_token:
            change_token = Utils.get_safe_value(self.get('/changes/startPageToken', parameters = self.prepare_parameters()), 'startPageToken')
        extra_info = {}
        parameters = self.prepare_parameters()
        parameters['pageToken'] = change_token
        parameters['pageSize'] = 1000
        parameters['fields'] = 'kind,nextPageToken,newStartPageToken,changes(kind,fileId,removed,changeType,time,file(%s))' % self._get_field_parameters()
        f = self.get('/changes', parameters = parameters)
        changes = self.process_files(f, parameters, include_download_info=True, extra_info=extra_info)
        self.persist_change_token(Utils.get_safe_value(extra_info, 'change_token'))
        return changes
