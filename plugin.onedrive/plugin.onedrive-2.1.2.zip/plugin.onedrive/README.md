# OneDrive KODI Add-on
OneDrive for KODI

Play all your media from Microsoft OneDrive including Videos, Music and Pictures. 
* Unlimited personal or business accounts
* Playback your music and videos. Listing of videos with thumbnails.
* Use OneDrive as a source.
* Subtitles can be assigned automatically if a .str file exists next to the video. 
* Export your videos to your library (.strm files). You can export your music too, but kodi won't support it yet. It's a Kodi issue for now.
* Show your photos individually or run a slideshow of them. Listing of pictures with thumbnails.
* Auto-Refreshed slideshow.
* Use of OAuth 2 login. You don't have to write your user/password within the add-on. Use the login process in your browser.
* Extremely fast. Using the Microsoft Graph API

This program is not affiliated with or sponsored by Microsoft.
